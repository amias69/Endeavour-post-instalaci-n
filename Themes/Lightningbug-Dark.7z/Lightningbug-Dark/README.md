# Lightningbug Theme
GTK3 themes base on : [Arc-Themes](https://github.com/horst3180/arc-theme) </br>
GTK2 themes base on : [Arc-Themes](https://github.com/horst3180/arc-theme) </br>
Cinnamon themes base on : [Arc-Themes](https://github.com/horst3180/arc-theme) </br>
Gnome-shell themes base on : [Gnome-shell themes](https://gitlab.gnome.org/GNOME/gnome-shell/-/tree/gnome-3-38/data/theme) </br>
Xfwm4 themes base on : [Xfwm4 Default-theme](https://gitlab.xfce.org/Dridi/xfwm4/-/tree/master/themes/default) </br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br></br>
Theme can be download [here](https://www.pling.com/p/1238824/)</br></br>
SCREENSHOTS:</br>
![lightningbugscreenshot](https://i.ibb.co/DpvzB8L/lightningbug-tabs-improve.png "Lightningbug screenshot")</br>


