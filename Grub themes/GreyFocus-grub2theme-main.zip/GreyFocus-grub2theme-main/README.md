# GreyFocus-grub2theme
A simple grey theme based on Stylish by vinceliuice.

![Preview](https://github.com/Xuaolu/GreyFocus-grub2theme/assets/119270979/ae1dcef0-8cd7-4ca3-934a-b43aaec562d6)
